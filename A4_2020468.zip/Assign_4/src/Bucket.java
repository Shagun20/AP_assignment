import java.util.*;
public class Bucket {
private ArrayList<Soft_toys> toys= new ArrayList<Soft_toys>();
public void add_toys(Soft_toys s) {
	this.toys.add(s);
	
}
public ArrayList<Soft_toys> get_toys(Soft_toys s) {
	return this.toys;
	
}
public void print_toys() {
	System.out.println("Soft toys won by you are:");
	try {
	for(Soft_toys s : toys) {
		System.out.print(s.get_name()+" ");
	}}
	catch(NullPointerException e) {
		System.out.print("No toys won ! ");
		return;
	}
}

}
