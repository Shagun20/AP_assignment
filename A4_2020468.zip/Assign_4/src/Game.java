import java.util.*;
class Exception1 extends Exception  
{  
    public Exception1(String str)  
    {  
        // Calling constructor of parent Exception  
        super(str);  
    }  
}  




public class Game {
	
	
	private static Tiles t;
	private static Bucket b=new Bucket();
	
    private static ArrayList<Tiles> tiles = new ArrayList<Tiles>() ;
	private static String[] names= {"Betty-Boop", "Bugs-Bunny","Charlie-Brown","Daffy-Duck","Dennis-the-Menace",
    		"Donald-Duck","Garfield","Mickey-Mouse","Olive-Oyl","Popeye","Powerpuff-Girls",	"Road-Runner",
    		"Scooby-Doo",
    		"Snoopy",
    		" Ninja-Turtles",
    		"The-Simpsons",
    		"Tom",
    		"Jerry","Yogi-Bear","Doraemon" };
 
	
	public static void main(String[] args) {
		
		String message1="You are too energetic and zoomed past all the tiles. Muddy Puddle Splash!\r\n";
		
		for(int i=0;i<20; i++) {
			
			t= new Tiles(names[i], i);
			//System.out.println(names[7]);	
			tiles.add(t);
			
		}
	Scanner sc=new Scanner(System.in);
	int i=1;	
	System.out.println("Hit enter to initialize the game");
	sc.nextLine();
	System.out.println("Game is ready");
	while(i<=5) {
		
		Random rand=new Random();
		int randomNum = rand.nextInt((20-0) + 1) + 0;
			
		if(i==1)
		   System.out.println("Hit enter for your first hop");	
		if(i==2)
			System.out.println("Hit enter for your second hop");	
		if(i==3)
			System.out.println("Hit enter for your third hop");	
		if(i==4)
			System.out.println("Hit enter for your fourth hop");	
		if(i==5)	
		 System.out.println("Hit enter for your fifth hop");	
		
		sc.nextLine();
		//randomNum=20;
		if(randomNum==20)
			try{throw new Exception1(message1);
			}
		catch(Exception1 e) {
			System.out.println(message1);
		}
		else{System.out.println("You landed on tile "+ (randomNum+1));	
		
		if((randomNum+1)%2==0) {
			tiles.get(randomNum).printmessage();
			 try {
				 b.add_toys(tiles.get(randomNum).get_toy().clone());
					
				}
			catch (CloneNotSupportedException e) {
		// this will never happen
						
						System.out.println(" Could not create a clone of this toy");
			    }
		}
		
		else{
			System.out.println("Question answer round. Integer or strings?");
			//System.out.println("Question answer round. Integer or strings?");integer
		    String s=sc.nextLine();
		    if(s.equals("integer")) {
		    	//System.out.println("!");
		    	 GenericCalculator<Integer> g=new GenericCalculator<Integer>(0);
		    	 Integer ans= g.generate();
		    	 
		    	 try{
		    		 Integer answer=Integer.parseInt(sc.nextLine());
		    	 
		    	 if(ans!=null) {
		    		 if(g.compare(answer)) {
		    			 System.out.println("Correct answer\r\n"+ "You won" + tiles.get(randomNum).get_toy().get_name()); 
		    			 try {
		    				 b.add_toys(tiles.get(randomNum).get_toy().clone());
		    					
		    				}
		    			catch (CloneNotSupportedException e) {
		    		// this will never happen
		    						
		    						System.out.println(" Could not create a clone of this toy");
		    			    }
		    			 catch(InputMismatchException p) {
		    				 System.out.println(" Invalid answer ! No soft toys won");
		    			 }
		    		 }
		    		 else {
		    			 System.out.println("Incorrect answer\r\n"+ "You did not win any soft toy"); 
				    	  
		    		 }
		    	 }
		    	 else {
	    			 System.out.println("Incorrect answer\r\n"+ "You did not win any soft toy"); 
			    	  
	    		 }
		    	 
		    	 }
		    	 catch(ClassCastException e) {
		    		 System.out.println("Incorrect answer\r\n"+ "You did not win any soft toy"); 
			    	  
		    	 }
		    	 //throw exception
		    	
		    }
		    else if(s.equals("string")) {
		    	 GenericCalculator<String> g=new GenericCalculator<String>("");
		    	 String ans= g.generate();
		    	 try{
		    		String answer=sc.nextLine();
		    	 
		    	 if(ans!=null) {
		    		 if(g.compare(answer)) {
		    			 System.out.println("Correct answer\r\n"+ " You won" + tiles.get(randomNum).get_toy().get_name()); 	
		    			 try {
		    				 b.add_toys(tiles.get(randomNum).get_toy().clone());
		    					
		    				}
		    			catch (CloneNotSupportedException e) {
		    		// this will never happen
		    						
		    						System.out.println(" Could not create a clone of this toy");
		    			    }
		    					
		    			
		    		 //clone and add to bucket
		    		 }
		    		 else {
		    			 System.out.println("Incorrect answer\r\n"+ "You did not win any soft toy"); 
				    	  
		    		 }
		    	 }
		    	 }
		    	 catch(ClassCastException e) {
		    		 System.out.println("Incorrect answer\r\n"+ "You did not win any soft toy"); 
			    	  
		    	 }
		    	
		    }
		    
		    else {
		    	System.out.println("You have only 2 choices for the Question answer round. Integer or strings?");
		    }
		
		
		
		
		
		
		}
		
	
	
	}
		i++;
	}
	System.out.println("Game Over");
	b.print_toys();	
		
}
	}
