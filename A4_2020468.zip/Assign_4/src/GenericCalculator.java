import java.util.*;
public class GenericCalculator<T1> {
	private T1 t;
	private T1 ans;
	public GenericCalculator(T1 t) {
	this.t=t;
	}
   public boolean compare(T1 answer) {
	   if(this.ans.equals(answer)) {
		   return true;
	   }
	   else
		   return false;
   }
   public T1 generate() {
	   
	   int i=0;
	if(this.t instanceof String) {
	String s1="";
	String s2="";
	String s3="";
	String SALTCHARS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijk"+"lmnopqrstuvwxyz!@#$%&";
	while(i<2) {
	
	Random rand=new Random();
	String salt ="";
	while (salt.length() < 4) {
        int index = rand.nextInt(((SALTCHARS.length()-1)-0) + 1) + 0;
		salt=salt+ (SALTCHARS.charAt(index));
	
	}
	if(i==0) {
		s1=salt;
	}
	else if(i==1) {
		s2=salt;
	}
	i++;
	}
	s3=s1+s2;
	System.out.println("Calculate the concatenation of strings "+s1+" and "+s2);
	//System.out.println(" the concatenation of strings "+s1+" and "+s2 +"is" +s3);
	this.ans=(T1)s3;
	return (T1)s3;
	}
	
	
	
	else if( t instanceof Integer) {
		
	Random rd=new Random();
     Integer m1= rd.nextInt();
     Integer m2= rd.nextInt();
     System.out.println("Calculate the result of "+m1+" divided by "+m2);
     try {
        Integer c= m1/m2;// throw Exception
        this.ans=(T1)c;
        return (T1)c;
     }
     catch (ArithmeticException e) {
         // Exception handler
         System.out.println("Divided by zero is undefined- enter 0");
         Integer c=0;
         this.ans=(T1)c;
         return (T1)c;
         
     }
     
}
   
   return (T1)null;
   }
   
   }
