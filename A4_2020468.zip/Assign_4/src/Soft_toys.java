import java.util.*;
public class Soft_toys implements Cloneable {
private String name;
private Tiles tile;
private int tile_no;
public Soft_toys(String s, Tiles tile,int i) {
	this.name=s;
    this.tile=tile; // association
    this.tile_no=i;
}
public String get_name() {
	return this.name;
}
public Soft_toys clone() throws CloneNotSupportedException{
	try {
	Soft_toys t1 = (Soft_toys)super.clone();
	
	t1.name=this.name;
	t1.tile=this.tile;
	t1.tile_no=this.tile_no;
	 
	return t1;
	}
	catch (CloneNotSupportedException e) {
		// this will never happen
		
		return null;
		}
	
	
}
}

