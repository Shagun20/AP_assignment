import java.util.*;
public class Tiles {
private Soft_toys toy1;
private int no;

public Tiles(String s, int i) {
	this.toy1 = new Soft_toys(s,this, i);
	this.no=i;
	//System.out.println(s);
}
public Soft_toys get_toy() {
	return this.toy1;
}
public void printmessage() {
	 String message="You won a "+this.toy1.get_name()+"soft toy";
	System.out.println(message);
}

}